/* Leonida live content — the app downloads fresh content (news, guides, translations, new images)
   from the public feed at every launch, so content updates never need a new App Store version.
   Runs before app.js: applies the newest cached content synchronously, then checks the feed. */
(function () {
  'use strict';
  var FEED = 'https://raw.githubusercontent.com/erwanleveuzit/leonida-site/main/live/';
  var KEY = 'leonida-live';
  var started = Date.now();
  var bundled = window.LEONIDA_DATA || {};
  var live = { lang: {} };
  window.LEONIDA_LIVE = live;
  live.feed = FEED;

  function newer(a, b) { return String(a || '') > String(b || ''); }
  function fixMedia(d) { // images that are not inside the installed app are loaded from the feed
    var B = window.LEONIDA_BUNDLED; if (!B) return d;
    (function walk(o) {
      if (!o || typeof o !== 'object') return;
      Object.keys(o).forEach(function (k) {
        var v = o[k];
        if (typeof v === 'string') { if (/^media\//.test(v) && !B[v]) o[k] = FEED + v; }
        else walk(v);
      });
    })(d);
    return d;
  }
  function read() { try { return JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { return null; } }
  function write(o) { try { localStorage.setItem(KEY, JSON.stringify(o)); return true; } catch (e) { return false; } }

  // 1. apply cached feed content if it is newer than what shipped in the app
  var cache = read();
  if (cache && cache.data && cache.data.entries && newer(cache.data.stamp, bundled.stamp)) {
    window.LEONIDA_DATA = fixMedia(cache.data);
    if (cache.ui) Object.keys(cache.ui).forEach(function (k) { window.LEONIDA_UI = window.LEONIDA_UI || {}; window.LEONIDA_UI[k] = cache.ui[k]; });
    live.lang = cache.lang || {};
    live.applied = cache.data.stamp;
  } else if (cache && cache.lang && cache.stamp && newer(cache.stamp, bundled.stamp)) {
    live.lang = cache.lang;
  }

  // 2. check the feed (quietly; offline is fine)
  function get(u) { return fetch(FEED + u + '?t=' + Math.floor(Date.now() / 300000), { cache: 'no-store' }).then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); }); }
  function check() {
    get('manifest.json').then(function (m) {
      var current = (read() || {}).stamp || bundled.stamp;
      if (!m || !newer(m.stamp, current) || !newer(m.stamp, bundled.stamp)) return;
      var langs = m.langs || [];
      return Promise.all([get('content.json'), m.ui ? get('ui.json') : Promise.resolve(null)].concat(langs.map(function (l) { return get('lang/' + l + '.json').catch(function () { return null; }); }))).then(function (res) {
        var data = res[0]; if (!data || !data.entries || !data.entries.length) return;
        var o = { stamp: m.stamp, data: data, ui: res[1], lang: {} };
        langs.forEach(function (l, i) { if (res[i + 2]) o.lang[l] = res[i + 2]; });
        if (!write(o)) { o.lang = {}; write(o); }
        // fresh content: reload right away if the app has just opened, otherwise use it next time
        if (Date.now() - started < 6000 && !live.reloaded) { try { sessionStorage.setItem('leonida-live-reload', '1'); } catch (e) { } location.reload(); }
        else live.pending = m.stamp;
      });
    }).catch(function () { /* offline or feed unavailable: keep current content */ });
  }
  try { live.reloaded = sessionStorage.getItem('leonida-live-reload') === '1'; sessionStorage.removeItem('leonida-live-reload'); } catch (e) { }
  if (!live.reloaded) check();
  document.addEventListener('visibilitychange', function () { if (!document.hidden && Date.now() - (live.lastCheck || started) > 15 * 60000) { live.lastCheck = Date.now(); started = Date.now(); live.reloaded = false; check(); } });
})();
