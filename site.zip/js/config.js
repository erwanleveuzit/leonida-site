/* Leonida — revenue config. Fill in when accounts exist; empty values are hidden in the app.
   affiliate: per language list of {name, url, primary?}; '*' applies to every language.
   Example: affiliate: { fr: [{ name: 'Amazon', url: 'https://www.amazon.fr/dp/XXXX?tag=leonida-21', primary: true }] } */
window.LEONIDA_CONFIG = {
  affiliate: {},
  donateUrl: ''
};
