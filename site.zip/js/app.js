/* Leonida 2.0 — app core. Vanilla JS, no build. */
(function () {
  'use strict';
  const D = window.LEONIDA_DATA, UI = window.LEONIDA_UI, LANGS = window.LEONIDA_LANGS;
  const VERSION = D.version;
  const LAUNCH = new Date(2026, 10, 19, 0, 0, 0); // local midnight, Nov 19 2026
  const PRELOAD = new Date(2026, 10, 12, 0, 0, 0);
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const byId = {}; D.entries.forEach((e) => (byId[e.id] = e));
  const mediaById = {}; D.media.forEach((m) => (mediaById[m.id] = m));
  const CATS = ['characters', 'places', 'vehicles', 'weapons', 'editions', 'essentials', 'music', 'shops', 'gear', 'activities', 'features', 'videos'];
  const REGIONS = ['place-0', 'place-1', 'place-2', 'place-3', 'place-4', 'place-5'];
  const CAST = ['jason', 'lucia', 'cal', 'boobie', 'drequan', 'dimez', 'raul', 'brian'];
  const TRAILERS = ['video-launch', 'video-extended', 'video-trailer2', 'video-trailer1'];
  const STORE = 'leonida-v2';
  const CFG = window.LEONIDA_CONFIG || {};
  const PS_LOCALE = { fr: 'fr-fr', en: 'en-us', es: 'es-es', pt: 'pt-br', de: 'de-de', it: 'it-it', ja: 'ja-jp', ko: 'ko-kr', zh: 'en-us', ru: 'en-us', tr: 'tr-tr', pl: 'pl-pl' };
  function shopLinks() {
    const l = S.lang, aff = (CFG.affiliate || {})[l] || (CFG.affiliate || {})['*'] || [];
    const base = [{ name: 'PlayStation Store', url: 'https://www.playstation.com/' + PS_LOCALE[l] + '/games/grand-theft-auto-vi/' }, { name: 'Rockstar Store', url: 'https://store.rockstargames.com/game/buy-gta-vi' }];
    return aff.concat(base);
  }
  function buyHTML() {
    return '<div class="card" style="padding:16px"><b style="font-family:var(--display);font-size:20px;text-transform:uppercase">' + esc(t('buyTitle')) + '</b><div class="row" style="flex-wrap:wrap;margin-top:10px">' + shopLinks().map((x) => '<a class="btn btn-sm' + (x.primary ? ' btn-primary' : '') + '" target="_blank" rel="noopener sponsored" href="' + esc(x.url) + '">' + esc(x.name) + ' ›</a>').join('') + '</div><p class="tiny dim" style="margin-top:8px">' + esc(t('buyNote')) + '</p></div>';
  }
  function supportHTML() {
    if (!CFG.donateUrl) return '';
    return '<div class="card" style="padding:16px"><b style="font-family:var(--display);font-size:20px;text-transform:uppercase">' + esc(t('support')) + '</b><p class="small muted" style="margin:6px 0 10px">' + esc(t('supportNote')) + '</p><a class="btn btn-sm btn-primary" target="_blank" rel="noopener" href="' + esc(CFG.donateUrl) + '">♥ ' + esc(t('support')) + '</a></div>';
  }

  /* ---------- state ---------- */
  let S = { lang: 'fr', spoilers: false, favs: [], history: [], checks: [], view: 'grid', seen: 0 };
  function load() {
    try {
      const raw = JSON.parse(localStorage.getItem(STORE) || 'null');
      if (raw && typeof raw === 'object') S = Object.assign(S, raw);
      else {
        // migrate v1
        const v1 = JSON.parse(localStorage.getItem('leonida-v1') || 'null');
        if (v1) { S.favs = (v1.favorites || []).filter((id) => byId[id]); S.history = (v1.read || []).filter((id) => byId[id]); S.spoilers = !v1.spoilers; }
        const l = localStorage.getItem('leonida-language'); if (l === 'en') S.lang = 'en';
        else { const nav = (navigator.language || 'fr').slice(0, 2).toLowerCase(); if (LANGS.some((x) => x.code === nav)) S.lang = nav; }
        const cv = localStorage.getItem('leonida-catalog-view'); if (cv === 'list') S.view = 'list';
      }
    } catch (e) { /* storage unavailable */ }
    try { const ql = new URLSearchParams(location.search).get('lang'); if (ql && LANGS.some((x) => x.code === ql)) S.lang = ql; } catch (e) { /* ignore */ }
    if (!LANGS.some((x) => x.code === S.lang)) S.lang = 'fr';
  }
  function save() { try { localStorage.setItem(STORE, JSON.stringify(S)); } catch (e) { /* ignore */ } }

  /* ---------- i18n ---------- */
  const LANGPACK = {}; // code -> {ui, entries, news, timeline, checklist}
  function ui() { return UI[S.lang] || (LANGPACK[S.lang] && LANGPACK[S.lang].ui) || UI.en; }
  function t(path, vars) {
    const get = (o) => path.split('.').reduce((a, k) => (a && a[k] != null ? a[k] : undefined), o);
    let s = get(ui()); if (s == null) s = get(UI.en); if (s == null) s = get(UI.fr); if (s == null) s = path;
    if (vars) Object.keys(vars).forEach((k) => { s = s.split('{' + k + '}').join(vars[k]); });
    return s;
  }
  function tx(e, field) { // entry text in current language
    const l = S.lang;
    let v;
    if (e.i18n && e.i18n[l]) v = e.i18n[l][field];
    else if (LANGPACK[l] && LANGPACK[l].entries[e.id]) v = LANGPACK[l].entries[e.id][field];
    if (v == null || (Array.isArray(v) && !v.length) || v === '') v = e.i18n.en[field];
    if (v == null || (Array.isArray(v) && !v.length) || v === '') v = e.i18n.fr[field];
    return v;
  }
  function txNews(n, f) { const l = S.lang; if (n.i18n[l]) return n.i18n[l][f]; if (LANGPACK[l] && LANGPACK[l].news[n.id]) return LANGPACK[l].news[n.id][f]; return n.i18n.en[f]; }
  function txTl(x) { const l = S.lang; if (x.i18n[l]) return x.i18n[l]; if (LANGPACK[l] && LANGPACK[l].timeline[x.date]) return LANGPACK[l].timeline[x.date]; return x.i18n.en; }
  function txCk(c) { const l = S.lang; if (c.i18n[l]) return c.i18n[l]; if (LANGPACK[l] && LANGPACK[l].checklist[c.id]) return LANGPACK[l].checklist[c.id]; return c.i18n.en; }
  function catName(c) { return t('cats.' + c); }
  const LOCALE = { fr: 'fr-FR', en: 'en-GB', es: 'es-ES', pt: 'pt-BR', de: 'de-DE', it: 'it-IT', ja: 'ja-JP', ko: 'ko-KR', zh: 'zh-CN', ru: 'ru-RU', tr: 'tr-TR', pl: 'pl-PL' };
  function fmtDate(iso, opts) { try { return new Date(iso + (iso.length === 10 ? 'T12:00:00' : '')).toLocaleDateString(LOCALE[S.lang] || 'en', opts || { day: 'numeric', month: 'long', year: 'numeric' }); } catch (e) { return iso; } }
  function setLang(code, cb) {
    if (code === S.lang && (UI[code] || LANGPACK[code])) { cb && cb(); return; }
    const apply = () => { S.lang = code; save(); document.documentElement.lang = code; renderNav(); render(); cb && cb(); };
    if (UI[code] || LANGPACK[code]) return apply();
    const LIVE = window.LEONIDA_LIVE || {};
    if (LIVE.lang && LIVE.lang[code]) { LANGPACK[code] = LIVE.lang[code]; return apply(); } // fresher translation from the live feed
    const s = document.createElement('script'); s.src = 'js/lang/' + code + '.js?v=' + VERSION;
    s.onload = () => { if (window.LEONIDA_LANG && window.LEONIDA_LANG[code]) { LANGPACK[code] = window.LEONIDA_LANG[code]; apply(); } else { toast('…'); } };
    s.onerror = () => toast('Translation unavailable offline');
    document.head.appendChild(s);
  }

  /* ---------- helpers ---------- */
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
  const ICON = {
    home: '<svg viewBox="0 0 24 24"><path d="M3 11.5 12 4l9 7.5"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/></svg>',
    map: '<svg viewBox="0 0 24 24"><path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2z"/><path d="M9 4v14M15 6v14"/></svg>',
    guide: '<svg viewBox="0 0 24 24"><rect x="3" y="3" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="3" width="7.5" height="7.5" rx="2"/><rect x="3" y="13.5" width="7.5" height="7.5" rx="2"/><rect x="13.5" y="13.5" width="7.5" height="7.5" rx="2"/></svg>',
    news: '<svg viewBox="0 0 24 24"><path d="M4 5h13v14H6a2 2 0 0 1-2-2V5z"/><path d="M17 9h3v8a2 2 0 0 1-2 2"/><path d="M7 9h7M7 13h7M7 16h4"/></svg>',
    me: '<svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3.6"/><path d="M5 20.5v-1.5a6 6 0 0 1 6-6h2a6 6 0 0 1 6 6v1.5"/></svg>',
    heart: '<svg viewBox="0 0 24 24"><path d="M12 20.5s-7.5-4.7-7.5-10A4.2 4.2 0 0 1 12 8a4.2 4.2 0 0 1 7.5 2.5c0 5.3-7.5 10-7.5 10z"/></svg>',
    share: '<svg viewBox="0 0 24 24"><path d="M12 15V4"/><path d="m8 8 4-4 4 4"/><path d="M5 12v7a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7"/></svg>',
    back: '<svg viewBox="0 0 24 24"><path d="m14 6-6 6 6 6"/></svg>',
    chev: '<svg viewBox="0 0 24 24"><path d="m9 6 6 6-6 6"/></svg>',
    search: '<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>',
    check: '<svg viewBox="0 0 24 24"><path d="m5 12 5 5L20 7"/></svg>',
    shield: '<svg viewBox="0 0 24 24"><path d="M12 3 5 6v6c0 4.5 3 7.5 7 9 4-1.5 7-4.5 7-9V6l-7-3z"/><path d="m9 12 2 2 4-4"/></svg>',
    car: '<svg viewBox="0 0 24 24"><path d="M5 13 7 7h10l2 6"/><rect x="3" y="13" width="18" height="6" rx="2"/><circle cx="7.5" cy="19" r="1.6"/><circle cx="16.5" cy="19" r="1.6"/></svg>',
    gun: '<svg viewBox="0 0 24 24"><path d="M3 9h16l2 2-2 2H9l-1 5H5l1-5H3z"/></svg>',
    pin: '<svg viewBox="0 0 24 24"><path d="M12 21s-6-5.5-6-11a6 6 0 0 1 12 0c0 5.5-6 11-6 11z"/><circle cx="12" cy="10" r="2.2"/></svg>',
    users: '<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3"/><path d="M3 20v-1a5 5 0 0 1 5-5h2a5 5 0 0 1 5 5v1"/><circle cx="17" cy="9" r="2.5"/><path d="M16 14h1a4 4 0 0 1 4 4v2"/></svg>',
    radio: '<svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="12" rx="2"/><path d="m6 8 10-4"/><circle cx="9" cy="14" r="2.5"/><path d="M15 12h3M15 16h3"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M7 5v14l11-7z"/></svg>',
    photo: '<svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.8"/><path d="m21 16-5-5-8 8"/></svg>',
    box: '<svg viewBox="0 0 24 24"><path d="m12 3 8 4.5v9L12 21l-8-4.5v-9z"/><path d="M4 7.5 12 12l8-4.5M12 12v9"/></svg>',
    clock: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="8.5"/><path d="M12 7v5l3 2"/></svg>',
    ext: '<svg viewBox="0 0 24 24"><path d="M14 4h6v6"/><path d="M20 4 10 14"/><path d="M19 13v6H5V5h6"/></svg>',
    grid: '<svg viewBox="0 0 24 24"><rect x="4" y="4" width="7" height="7"/><rect x="13" y="4" width="7" height="7"/><rect x="4" y="13" width="7" height="7"/><rect x="13" y="13" width="7" height="7"/></svg>',
    list: '<svg viewBox="0 0 24 24"><path d="M4 6h16M4 12h16M4 18h16"/></svg>',
    info: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><rect x="6" y="5" width="4" height="14"/><rect x="14" y="5" width="4" height="14"/></svg>',
    globe: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>',
    download: '<svg viewBox="0 0 24 24"><path d="M12 4v11"/><path d="m8 11 4 4 4-4"/><path d="M5 19h14"/></svg>',
  };
  function img(e, i) { // first image url + alt for entry
    const m = e.media && e.media.length ? mediaById[e.media[i || 0]] : null;
    if (m) return { src: m.src, hi: m.hi, alt: m.title };
    if (e.posters && e.posters.length) return { src: e.posters[i || 0] || e.posters[0], hi: null, alt: tx(e, 'name') };
    return null;
  }
  function images(e) {
    const out = (e.media || []).map((id) => mediaById[id]).filter(Boolean).map((m) => ({ src: m.src, hi: m.hi, alt: m.title, id: m.id }));
    (e.posters || []).forEach((p) => out.push({ src: p, hi: null, alt: tx(e, 'name') }));
    return out;
  }
  function initials(e) { return tx(e, 'name').split(/\s+/).map((w) => w[0]).join('').slice(0, 2).toUpperCase(); }
  function isFav(id) { return S.favs.indexOf(id) >= 0; }
  function toggleFav(id) { const i = S.favs.indexOf(id); if (i >= 0) S.favs.splice(i, 1); else S.favs.unshift(id); save(); toast(i >= 0 ? t('favRemoved') : t('favAdded')); $$('[data-fav="' + id + '"]').forEach((b) => { b.classList.toggle('on', isFav(id)); b.setAttribute('aria-label', isFav(id) ? t('unfav') : t('fav')); }); }
  function favBtn(id, cls) { return '<button class="fav-btn ' + (cls || '') + (isFav(id) ? ' on' : '') + '" data-action="fav" data-fav="' + id + '" aria-label="' + esc(isFav(id) ? t('unfav') : t('fav')) + '">' + ICON.heart + '</button>'; }
  let toastT; function toast(msg) { const el = $('#toast'); el.textContent = msg; el.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 2200); }
  function go(hash) { location.hash = hash; }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function fmtTime(s) { s = Math.max(0, Math.floor(s)); return Math.floor(s / 60) + ':' + pad(s % 60); }

  /* ---------- components ---------- */
  function tile(e, cls, opts) {
    opts = opts || {}; const im = img(e); const cat = e.cat;
    const inner = (im ? '<img src="' + im.src + '" alt="' + esc(im.alt) + '" loading="lazy">' : '<div style="height:100%;display:grid;place-items:center"><div class="avatar" style="width:64px;height:64px;font-size:28px">' + esc(initials(e)) + '</div></div>')
      + '<div class="shade"></div><div class="cap">' + (opts.kicker ? '<div class="kicker">' + esc(opts.kicker) + '</div>' : '') + '<h3>' + esc(tx(e, 'name')) + '</h3>' + (opts.noDesc ? '' : '<p>' + esc(tx(e, 'tagline') || tx(e, 'summary')) + '</p>') + '</div><div class="led"></div>'
      ;
    return '<a class="tile ' + (cls || '') + '" href="#e/' + e.id + '">' + inner + '</a>';
  }
  function listRow(e) {
    const im = img(e);
    return '<a class="card list-row" href="#e/' + e.id + '">' + (im ? '<img src="' + im.src + '" alt="" loading="lazy">' : '<div class="avatar">' + esc(initials(e)) + '</div>') + '<div class="lt"><div class="cat">' + esc(t('catsOne.' + e.cat)) + '</div><b>' + esc(tx(e, 'name')) + '</b><span>' + esc(tx(e, 'tagline') || tx(e, 'summary')) + '</span></div>' + favBtn(e.id) + '</a>';
  }
  function sectionHead(title, sub, link, linkLabel) {
    return '<div class="section-head"><div><h2>' + esc(title) + '</h2>' + (sub ? '<div class="sub">' + esc(sub) + '</div>' : '') + '</div>' + (link ? '<a class="link" href="' + link + '">' + esc(linkLabel || t('seeAll')) + ' ›</a>' : '') + '</div>';
  }
  function newsCard(n, big) {
    return '<a class="card news-card' + (big ? ' news-big' : '') + '" href="#n/' + esc(n.id) + '">' + '<img src="' + (n.img || D.extra.keyart1) + '" alt="" loading="lazy">' + '<div class="nb"><time>' + esc(fmtDate(n.date, { day: 'numeric', month: 'short', year: 'numeric' })) + '</time><h3>' + esc(txNews(n, 'title')) + '</h3><p>' + esc(txNews(n, 'summary')) + '</p></div></a>';
  }
  function videoCard(id, cls) {
    const v = D.videos[id], e = byId[id];
    const dur = { 'video-extended': '26:48', 'video-trailer2': '2:47', 'video-trailer1': '1:31' }[id] || '';
    return '<div class="video-card ' + (cls || '') + '" data-video="' + id + '"><img src="' + v.poster + '" alt="" loading="lazy">' + (dur ? '<span class="dur">' + dur + '</span>' : '') + '<button class="play" data-action="play-video" data-id="' + id + '" aria-label="' + esc(t('watch')) + '"><span class="play-btn"></span></button><div class="cap"><h3>' + esc(e ? tx(e, 'name') : v.title) + '</h3><p>' + esc(e ? (tx(e, 'tagline') || '') : '') + '</p></div></div>';
  }
  function playVideo(id, card) {
    const v = D.videos[id];
    stopAllMedia();
    card.classList.add('playing');
    card.innerHTML = '<video controls autoplay playsinline preload="metadata" poster="' + v.poster + '"><source src="' + v.mp4 + '" type="video/mp4"></video>';
    const vid = $('video', card);
    vid.addEventListener('error', () => { card.classList.remove('playing'); card.innerHTML = '<div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;padding:20px;text-align:center;background:#0a0712"><p class="muted small">' + esc(t('error.video')) + '</p><a class="btn btn-sm" target="_blank" rel="noopener" href="' + esc(v.sourceUrl) + '">' + ICON.ext + ' rockstargames.com</a></div>'; }, { once: true });
    bump(id);
  }
  let audio = null, audioId = null, audioTimer = null;
  function stopAllMedia() { $$('video').forEach((v) => { try { v.pause(); } catch (e) { } }); if (audio) { audio.pause(); } }
  function radioPlayer(id) {
    const r = D.radios[id];
    const playing = audioId === id && audio && !audio.paused;
    return '<div class="player" data-radio="' + id + '"><div class="controls"><button class="pp" data-action="radio" data-id="' + id + '" aria-label="' + esc(playing ? t('pause') : t('play')) + '">' + (playing ? ICON.pause : ICON.play) + '</button><div class="prog" data-action="seek" data-id="' + id + '"><i style="width:0%"></i></div><span class="time">0:00</span></div><div class="chapters">' + r.chapters.map((c, i) => '<button class="chapter' + (c.title === r.name ? ' jingle' : '') + '" data-action="chapter" data-id="' + id + '" data-t="' + c.startPosition + '"><span class="ct">' + fmtTime(c.startPosition) + '</span><span class="cn"><b>' + esc(c.title) + '</b><span>' + esc(c.artists) + '</span></span></button>').join('') + '</div><p class="tiny dim">' + esc(t('previewNote')) + '</p></div>';
  }
  function toggleRadio(id) {
    const r = D.radios[id];
    if (audioId !== id) {
      stopAllMedia();
      if (audio) { audio.src = ''; }
      audio = new Audio(r.url); audio.preload = 'metadata'; audioId = id;
      audio.addEventListener('error', () => toast(t('error.audio')));
      audio.addEventListener('ended', () => syncRadioUI());
      audio.addEventListener('timeupdate', syncRadioUI);
      audio.play().catch(() => toast(t('error.audio')));
      bump(id);
    } else if (audio.paused) audio.play(); else audio.pause();
    setTimeout(syncRadioUI, 50);
  }
  function syncRadioUI() {
    $$('.player').forEach((p) => {
      const id = p.dataset.radio, on = id === audioId && audio;
      const pp = $('.pp', p), prog = $('.prog i', p), time = $('.time', p);
      const playing = on && !audio.paused;
      pp.innerHTML = playing ? ICON.pause : ICON.play;
      const cur = on ? audio.currentTime : 0, dur = on && audio.duration ? audio.duration : 0;
      prog.style.width = dur ? (cur / dur * 100) + '%' : '0%'; time.textContent = fmtTime(cur);
      const ch = D.radios[id].chapters; let ci = -1; ch.forEach((c, i) => { if (on && cur >= c.startPosition) ci = i; });
      $$('.chapter', p).forEach((b, i) => b.classList.toggle('current', i === ci));
    });
  }
  function spotifyEmbed(id) {
    const s = D.singles[id];
    return '<iframe class="spotify" src="https://open.spotify.com/embed/track/' + s.spotify + '?utm_source=generator&theme=0" loading="lazy" allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" title="' + esc(s.title) + '"></iframe>';
  }
  function spoilerWrap(html, id) {
    if (!S.spoilers) return html;
    return '<div class="spoiler" data-spoiler="' + id + '"><div class="blur">' + html + '</div><div class="veil"><b>' + esc(t('spoilerTitle')) + '</b><p>' + esc(t('spoilerDesc')) + '</p><button class="btn btn-sm" data-action="reveal">' + esc(t('reveal')) + '</button></div></div>';
  }
  function countdownHTML() {
    return '<div class="countdown" id="countdown">' + ['days', 'hours', 'minutes', 'seconds'].map((k) => '<div class="cd"><b data-cd="' + k + '">–</b><span>' + esc(t(k)) + '</span></div>').join('') + '</div>';
  }
  function tickCountdown() {
    const el = $('#countdown'); if (!el) return;
    const now = new Date(); let target = LAUNCH, label = t('countdown');
    const lab = $('#cd-label');
    if (now >= LAUNCH) { if (lab) lab.textContent = t('launched'); el.querySelectorAll('b').forEach((b) => (b.textContent = '0')); return; }
    let diff = target - now; const d = Math.floor(diff / 864e5); diff -= d * 864e5; const h = Math.floor(diff / 36e5); diff -= h * 36e5; const m = Math.floor(diff / 6e4); diff -= m * 6e4; const s = Math.floor(diff / 1e3);
    const set = (k, v) => { const b = el.querySelector('[data-cd="' + k + '"]'); if (b && b.textContent !== String(v)) b.textContent = v; };
    set('days', d); set('hours', pad(h)); set('minutes', pad(m)); set('seconds', pad(s));
    if (lab) lab.textContent = label;
  }
  setInterval(tickCountdown, 1000);

  /* ---------- views ---------- */
  function viewHome() {
    const latest = D.news.slice(0, 3);
    const hero = D.extra.trailer;
    const preloadIn = Math.ceil((PRELOAD - new Date()) / 864e5);
    let h = '<div class="view">';
    h += '<section class="hero"><img src="' + hero + '" alt="" fetchpriority="high"><div class="hero-body"><div class="kicker">' + esc(t('home.heroKicker')) + '</div><h1>' + esc(t('home.hello')).replace(/Leonida/, '<em>Leonida</em>') + '</h1>'
      + '<div class="pills"><span class="pill pink">' + esc(t('releaseDate')) + '</span><span class="pill cyan">' + esc(t('platformsShort')) + '</span></div>'
      + '<div class="kicker" id="cd-label" style="color:var(--cyan);margin-bottom:8px">' + esc(t('countdown')) + '</div>' + countdownHTML()
      + '<div class="cta"><button class="btn btn-primary" data-action="play-video-route" data-id="video-launch">' + ICON.play + ' ' + esc(tx(byId['video-launch'], 'name')) + '</button></div></div></section>';
    // news
    h += '<section class="section">' + sectionHead(t('home.latest'), null, '#media/news') + '<div class="news-list">' + latest.map((n, i) => newsCard(n, false)).join('') + '</div></section>';
    // trailers
    h += '<section class="section">' + sectionHead(t('home.trailers'), null, '#media/videos') + '<div class="hscroll">' + TRAILERS.map((id) => '<div style="width:min(86vw,420px)">' + videoCard(id) + '</div>').join('') + '</div></section>';
    // cast
    h += '<section class="section">' + sectionHead(t('home.cast'), null, '#guide/characters') + '<div class="hscroll">' + CAST.map((id, i) => { const e = byId[id], im = img(e); return '<a class="cast-card' + (i < 2 ? ' lead' : '') + '" href="#e/' + id + '"><div class="ph"><img src="' + im.src + '" alt="" loading="lazy"></div><h3>' + esc(tx(e, 'name')) + '</h3><p>' + esc(tx(e, 'tagline')) + '</p></a>'; }).join('') + '</div></section>';
    h += footerHTML() + '</div>';
    return h;
  }
  function timelineHTML() {
    const today = new Date().toISOString().slice(0, 10);
    let nextMarked = false;
    return '<div class="timeline">' + D.timeline.map((x) => { const past = x.date < today; let cls = past ? 'past' : ''; if (!past && !nextMarked) { cls = 'next'; nextMarked = true; } if (x.launch) cls += ' launch'; const label = txTl(x); const inner = x.id ? '<a class="tt" href="#e/' + x.id + '">' + esc(label) + '</a>' : '<div class="tt">' + esc(label) + '</div>'; return '<div class="tl ' + cls + '"><div class="dot"><i></i></div><div><time>' + esc(fmtDate(x.date)) + (cls.indexOf('next') >= 0 ? ' · ' + esc(t('timeline.next')) : '') + '</time>' + inner + '</div></div>'; }).join('') + '</div>';
  }
  function editionsHTML() {
    const std = byId.standard, ult = byId.ultimate, vin = byId.vintage;
    const ultItems = ['cheetah', 'morgan', 'variants', 'vice-style', 'safehouse', 'ganado', 'rideout', 'sara', 'squalo', 'stock305', 'dominator', 'fang', 'willie', 'goodtime', 'ptt', 'classic'];
    return '<div class="editions"><div class="card ed"><span class="chip small tag">' + esc(t('edition.standard')) + '</span><h3>' + esc(tx(std, 'name')) + '</h3><p class="muted small">' + esc(tx(std, 'tagline')) + '</p><ul><li>' + esc(tx(std, 'summary')) + '</li><li>' + esc(t('edition.preorder')) + ' : ' + esc(tx(vin, 'name')) + '</li></ul><a class="link" href="#e/standard">' + esc(t('more')) + ' ›</a></div>'
      + '<div class="card ed ultimate"><span class="chip small tag active">' + esc(t('edition.ultimate')) + ' · ' + esc(t('edition.items16')) + '</span><h3>' + esc(tx(ult, 'name')) + '</h3><p class="muted small">' + esc(tx(ult, 'tagline')) + '</p><ul>' + ultItems.slice(0, 6).map((id) => '<li><a href="#e/' + id + '">' + esc(tx(byId[id], 'name')) + '</a></li>').join('') + '<li class="muted">+ 10 …</li></ul><div class="row" style="gap:14px"><a class="link" href="#e/ultimate">' + esc(t('more')) + ' ›</a><a class="link" href="#e/upgrade" style="color:var(--pink-2)">' + esc(t('edition.upgrade')) + ' ›</a></div></div></div>';
  }
  function footerHTML() {
    return '<footer class="wrap" style="margin-top:32px;padding-bottom:10px"><p class="tiny dim">' + esc(t('unofficial')) + '</p></footer>';
  }

  function viewLeonida() {
    const places = D.entries.filter((e) => e.cat === 'places' && REGIONS.indexOf(e.id) < 0);
    let h = '<div class="view"><div class="page-title"><div class="kicker">Grand Theft Auto VI</div><h1>' + esc(t('leonida.title')) + '</h1><p>' + esc(t('leonida.sub')) + '</p></div>';
    h += '<section class="section">' + sectionHead(t('leonida.regions')) + '<div class="grid grid-2">' + REGIONS.map((id) => tile(byId[id], '')).join('') + '</div></section>';
    h += '<section class="section">' + sectionHead(t('leonida.places'), t('entriesN', { n: places.length })) + '<div class="places-list">' + places.map((e) => { const im = img(e); const parent = e.context ? byId[e.context] : null; return '<a class="card place-row" href="#e/' + e.id + '">' + (im ? '<img src="' + im.src + '" alt="" loading="lazy">' : '') + '<div class="pt"><b>' + esc(tx(e, 'name')) + '</b><span>' + esc(parent ? tx(parent, 'name') + ' · ' : '') + esc(tx(e, 'summary')) + '</span></div>' + ICON.chev.replace('<svg', '<svg style="width:18px;height:18px;fill:none;stroke:var(--dim);stroke-width:2"') + '</a>'; }).join('') + '</div></section>';
    return h + footerHTML() + '</div>';
  }

  let guideCat = 'all', guideFavs = false;
  function viewGuide(cat) {
    if (cat) guideCat = cat;
    const list = D.entries.filter((e) => (guideCat === 'all' || e.cat === guideCat) && (!guideFavs || isFav(e.id)));
    list.sort((a, b) => (CATS.indexOf(a.cat) - CATS.indexOf(b.cat)) || D.entries.indexOf(a) - D.entries.indexOf(b));
    let h = '<div class="view"><div class="page-title"><h1>' + esc(t('guide.title')) + '</h1><p>' + esc(t('guide.sub')) + ' · ' + esc(t('entriesN', { n: D.entries.length })) + '</p></div>';
    h += '<div class="toolbar" style="margin-top:14px"><button class="searchbar" data-action="search">' + ICON.search + '<span>' + esc(t('searchPlaceholder')) + '</span></button></div>';
    if (guideCat !== 'all' || guideFavs) h += '<div class="chips"><button class="chip' + (guideCat === 'all' && !guideFavs ? ' active' : '') + '" data-action="cat" data-cat="all">' + esc(t('guide.all')) + '</button><button class="chip' + (guideFavs ? ' active' : '') + '" data-action="cat-favs">♥ ' + esc(t('guide.favoritesOnly')) + '</button>' + CATS.map((c) => '<button class="chip' + (guideCat === c && !guideFavs ? ' active' : '') + '" data-action="cat" data-cat="' + c + '">' + esc(catName(c)) + ' <span class="dim">' + D.entries.filter((e) => e.cat === c).length + '</span></button>').join('') + '</div>';
    if (!list.length) h += '<div class="empty"><b>' + esc(t('guide.favoritesOnly')) + '</b>' + esc(t('me.noFavs')) + '</div>';
    else if (guideCat === 'all' && !guideFavs) {
      // grouped by category
      h += '<section class="section"><div class="stack">' + (S.favs.length ? '<button class="card cat-row" data-action="cat-favs"><b>♥ ' + esc(t('guide.favoritesOnly')) + '</b><span class="dim">' + S.favs.length + '</span>' + ICON.chev + '</button>' : '') + CATS.filter((c) => list.some((e) => e.cat === c)).map((c) => { const items = list.filter((e) => e.cat === c); const im = img(items[0]); return '<a class="card cat-row" href="#guide/' + c + '">' + (im ? '<img src="' + im.src + '" alt="" loading="lazy">' : '') + '<b>' + esc(catName(c)) + '</b><span class="dim">' + items.length + '</span>' + ICON.chev + '</a>'; }).join('') + '</div></section>';
    } else {
      h += '<section class="section"><div class="grid grid-2">' + list.map((e) => tile(e, '')).join('') + '</div></section>';
    }
    return h + footerHTML() + '</div>';
  }

  let mediaTab = 'news', photoFilter = 'all';
  function viewMedia(tab) {
    if (tab) mediaTab = tab;
    const tabs = ['news', 'videos', 'photos', 'music'];
    let h = '<div class="view"><div class="page-title"><h1>' + esc(t('media.title')) + '</h1></div><div class="chips" style="margin-top:12px">' + tabs.map((x) => '<a class="chip' + (mediaTab === x ? ' active' : '') + '" href="#media/' + x + '">' + esc(t('media.' + x)) + '</a>').join('') + '</div>';
    if (mediaTab === 'news') {
      h += '<section class="section"><div class="news-list">' + D.news.map((n, i) => newsCard(n, i === 0)).join('') + '</div></section>';
    } else if (mediaTab === 'videos') {
      const clips = D.entries.filter((e) => e.cat === 'videos' && TRAILERS.indexOf(e.id) < 0);
      h += '<section class="section">' + sectionHead(t('home.trailers')) + '<div class="stack">' + TRAILERS.map((id) => videoCard(id)).join('') + '</div></section>';
      h += '<section class="section">' + sectionHead(t('cats.videos'), t('videosN', { n: clips.length })) + '<div class="grid grid-2">' + clips.map((e) => '<div style="grid-column:span 1">' + videoCard(e.id) + '</div>').join('') + '</div><p class="wrap tiny dim" style="margin-top:10px">' + esc(t('videoNote')) + '</p></section>';
    } else if (mediaTab === 'photos') {
      const subjects = []; D.media.forEach((m) => { const s = m.title.replace(/\s\d+$/, ''); if (subjects.indexOf(s) < 0) subjects.push(s); });
      const list = D.media.filter((m) => photoFilter === 'all' || m.title.replace(/\s\d+$/, '') === photoFilter);
      h += '<section class="section">' + sectionHead(t('home.photosTitle'), t('photosN', { n: list.length })) + '<div class="chips"><button class="chip small' + (photoFilter === 'all' ? ' active' : '') + '" data-action="pf" data-f="all">' + esc(t('media.allPhotos')) + '</button>' + subjects.map((s) => '<button class="chip small' + (photoFilter === s ? ' active' : '') + '" data-action="pf" data-f="' + esc(s) + '">' + esc(s) + '</button>').join('') + '</div><div class="photo-grid">' + list.map((m) => '<button data-action="lb" data-idx="' + (m.id - 1) + '"><img src="' + m.src + '" alt="' + esc(m.title) + '" loading="lazy"></button>').join('') + '</div><p class="wrap tiny dim" style="margin-top:10px">' + esc(t('officialPhoto')) + ' — rockstargames.com/VI/media/screenshots</p></section>';
    } else {
      h += musicHTML();
    }
    return h + footerHTML() + '</div>';
  }
  function musicHTML() {
    const album = byId.album, score = byId.score;
    let h = '<section class="section">' + sectionHead(t('media.radios'), tx(byId['radio-more'], 'summary')) + '<div class="stack">' + Object.keys(D.radios).map((id) => { const r = D.radios[id], e = byId[id]; return '<div class="card" style="padding:14px"><div class="row" style="gap:14px;margin-bottom:10px"><div class="art" style="width:90px;height:60px;display:grid;place-items:center;border-radius:10px;background:rgba(255,255,255,.04);flex:none"><img src="' + r.art + '" alt="" style="max-height:52px;max-width:84px;object-fit:contain"></div><div style="min-width:0"><h3 style="font-size:22px">' + esc(r.name) + '</h3><p class="small muted">' + esc(tx(e, 'tagline')) + '</p><p class="tiny dim">' + esc(t('hosts', { h: r.hosts })) + '</p></div></div>' + radioPlayer(id) + '</div>'; }).join('') + '</div></section>';
    h += '<section class="section">' + sectionHead(t('media.album'), tx(album, 'tagline')) + '<div class="stack"><a class="card news-card" href="#e/album"><img src="' + D.extra.vinyl + '" alt=""><div class="nb"><time>Rockstar Games · Justice</time><h3>' + esc(tx(album, 'name')) + '</h3><p>' + esc(tx(album, 'summary')) + '</p></div></a>';
    h += '<div class="card" style="padding:4px 0">' + Array.from({ length: 9 }, (_, i) => 'single-' + i).map((id, i) => { const e = byId[id], s = D.singles[id]; return '<div><button class="single" style="width:100%;text-align:left" data-action="single" data-id="' + id + '"><span class="n">' + (i + 1) + '</span><span class="t"><b>' + esc(tx(e, 'name')) + '</b><span>' + esc(tx(e, 'summary')) + '</span></span><span class="pp" style="width:34px;height:34px">' + ICON.play + '</span></button><div class="single-embed" data-embed="' + id + '" style="padding:0 12px 10px" hidden></div></div>'; }).join('') + '</div><p class="tiny dim">' + esc(t('spotifyNote')) + '</p>';
    h += '<a class="card news-card" href="#e/score"><img src="' + D.extra.trailer + '" alt=""><div class="nb"><time>' + esc(t('media.score')) + '</time><h3>' + esc(tx(score, 'name')) + '</h3><p>' + esc(tx(score, 'summary')) + '</p></div></a></div></section>';
    return h;
  }

  function viewMe() {
    const favs = S.favs.map((id) => byId[id]).filter(Boolean), hist = S.history.map((id) => byId[id]).filter(Boolean).slice(0, 12);
    const done = S.checks.length, total = D.checklist.length; const lang = LANGS.find((l) => l.code === S.lang);
    let h = '<div class="view"><div class="page-title"><h1>' + esc(t('me.title')) + '</h1></div>';
    h += '<section class="section">' + sectionHead(t('me.checklist'), t('me.checklistDone', { a: done, b: total })) + '<div class="stack"><div class="progress" style="margin:0 0 4px"><i style="width:' + (done / total * 100) + '%"></i></div>' + D.checklist.map((c) => { const on = S.checks.indexOf(c.id) >= 0, tt = txCk(c); return '<div class="card check' + (on ? ' done' : '') + '"><button class="box" data-action="check" data-id="' + c.id + '" aria-pressed="' + on + '" aria-label="' + esc(tt[0]) + '">' + ICON.check + '</button><div class="ct"><b>' + esc(tt[0]) + '</b></div><a class="go" href="#e/' + c.link + '" aria-label="' + esc(t('open')) + '">' + ICON.chev + '</a></div>'; }).join('') + '</div></section>';
    h += '<section class="section">' + sectionHead(t('me.favorites'), t('entriesN', { n: favs.length })) + (favs.length ? '<div class="hscroll">' + favs.map((e) => tile(e, 'tile-sm')).join('') + '</div>' : '<div class="empty small">' + esc(t('me.noFavs')) + '</div>') + '</section>';
    h += '<section class="section">' + sectionHead(t('me.settings')) + '<div class="stack">'
      + '<button class="card setting" data-action="lang"><div class="st"><b>' + esc(t('me.language')) + '</b><span>' + esc(lang.flag + ' ' + lang.label) + ' · ' + LANGS.length + '</span></div>' + ICON.globe.replace('<svg', '<svg style="width:22px;height:22px;fill:none;stroke:var(--cyan);stroke-width:1.8"') + '</button>'
      + '<button class="card setting" data-action="spoilers" aria-pressed="' + S.spoilers + '"><div class="st"><b>' + esc(t('spoilers')) + '</b><span>' + esc(t('spoilersHelp')) + '</span></div><span class="switch' + (S.spoilers ? ' on' : '') + '"></span></button>'
      + '</div></section>';
    if (CFG.donateUrl) h += '<section class="section"><div class="stack">' + supportHTML() + '</div></section>';
    h += '<section class="section">' + sectionHead(t('me.about')) + '<div class="stack"><div class="card" style="padding:16px"><p class="small" style="line-height:1.6">' + esc(t('me.aboutText')) + '</p><p class="tiny dim" style="margin-top:10px">' + esc(t('unofficial')) + '</p><p class="tiny dim" style="margin-top:6px">' + esc(t('me.version')) + ' ' + VERSION + ' · ' + esc(t('me.dataChecked')) + ' ' + esc(fmtDate(D.checked)) + '</p></div></div></section>';
    return h + footerHTML() + '</div>';
  }

  function viewDetail(id) {
    const e = byId[id]; if (!e) return '<div class="empty"><b>404</b></div>';
    bump(id);
    const ims = images(e); const name = tx(e, 'name'), tag = tx(e, 'tagline'), body = tx(e, 'body'), facts = tx(e, 'facts'), summary = tx(e, 'summary');
    const src = D.sources[e.source] || { url: e.sourceUrl, title: e.publisher };
    let hero;
    if (ims.length) hero = '<div class="slides" id="slides">' + ims.map((m, i) => '<button data-action="lb-entry" data-entry="' + id + '" data-i="' + i + '" aria-label="' + esc(t('gallery')) + '"><img src="' + m.src + '" ' + (m.hi ? 'data-hi="' + esc(m.hi) + '"' : '') + ' alt="' + esc(m.alt) + '" ' + (i ? 'loading="lazy"' : 'fetchpriority="high"') + '></button>').join('') + '</div>' + (ims.length > 1 ? '<div class="dots" id="dots">' + ims.map((_, i) => '<i class="' + (i ? '' : 'on') + '"></i>').join('') + '</div>' : '');
    else hero = '<div style="height:100%;display:grid;place-items:center;background:radial-gradient(circle at 50% 40%,rgba(255,61,154,.25),transparent 60%)"><div class="avatar" style="width:120px;height:120px;font-size:52px">' + esc(initials(e)) + '</div></div>';
    let h = '<div class="view detail"><div class="detail-hero">' + hero + '<div class="topfade"></div><div class="detail-nav"><button class="icon-btn" data-action="back" aria-label="' + esc(t('back')) + '">' + ICON.back + '</button><div class="right"><button class="icon-btn" data-action="share" data-id="' + id + '" aria-label="' + esc(t('share')) + '">' + ICON.share + '</button>' + favBtn(id, 'icon-btn') + '</div></div></div>';
    h += '<div class="detail-head"><div class="kicker">' + esc(t('catsOne.' + e.cat)) + (e.publisher ? ' · ' + esc(e.publisher) : '') + '</div><h1>' + esc(name) + '</h1>' + (tag ? '<p class="tag">' + esc(tag) + '</p>' : '') + '</div>';
    h += '<div class="detail-body"><div class="col-main">';
    if (e.context) h += '<p class="context-note">' + ICON.info + ' ' + esc(t('contextImage', { name: tx(byId[e.context], 'name') })) + '</p>';
    if (e.noPortrait) h += '<p class="context-note">' + ICON.info + ' ' + esc(t('noPortrait')) + '</p>';
    if (e.video) { h += videoCard(e.video); if (D.videos[e.video].youtube) h += '<div class="row" style="gap:10px"><a class="btn btn-sm" target="_blank" rel="noopener" href="https://www.youtube.com/watch?v=' + D.videos[e.video].youtube + '">' + ICON.ext + ' ' + esc(t('youtube')) + '</a><span class="tiny dim">' + esc(t('netflix')) + '</span></div>'; }
    if (e.radio) h += '<div class="card" style="padding:14px"><div class="kicker" style="margin-bottom:8px">' + esc(t('hosts', { h: D.radios[e.radio].hosts })) + '</div>' + radioPlayer(e.radio) + '</div>';
    if (e.single) h += '<div class="card" style="padding:12px"><button class="btn btn-block" data-action="single" data-id="' + id + '">' + ICON.play + ' ' + esc(t('listen')) + ' · Spotify</button><div class="single-embed" data-embed="' + id + '" hidden></div><a class="link" style="display:inline-block;margin-top:8px" target="_blank" rel="noopener" href="' + esc(D.singles[id].url) + '">' + esc(t('openLink')) + ' ›</a></div>';
    const prose = '<div class="prose">' + (body && body.length ? body.map((p) => '<p>' + esc(p) + '</p>').join('') : '<p>' + esc(summary) + '</p>') + '</div>';
    h += e.spoiler ? spoilerWrap(prose, id) : prose;
    if (ims.length > 1) h += '<div><div class="kicker" style="margin-bottom:8px">' + esc(t('gallery')) + ' · ' + ims.length + '</div><div class="hscroll photo-strip" style="padding-left:0;padding-right:0">' + ims.map((m, i) => '<button data-action="lb-entry" data-entry="' + id + '" data-i="' + i + '"><img src="' + m.src + '" alt="' + esc(m.alt) + '" loading="lazy"></button>').join('') + '</div></div>';
    h += '</div><div class="col-side">';
    if (facts && facts.length) h += '<div><div class="kicker" style="margin-bottom:8px">' + esc(t('facts')) + '</div><dl class="facts">' + facts.map((f) => '<div><dt>' + esc(f[0]) + '</dt><dd>' + esc(f[1]) + '</dd></div>').join('') + '</dl></div>';
    h += '<div class="card source-box">' + ICON.shield + '<div><b>' + esc(t('source')) + ' · ' + esc(e.publisher) + '</b><div class="tiny">' + esc(src.title) + '</div><div class="tiny">' + esc(t('verifiedOn', { d: fmtDate(e.checked) })) + '</div><a class="link" target="_blank" rel="noopener" href="' + esc(e.sourceUrl) + '">' + esc(t('openSource')) + ' ›</a></div></div>';
    if (['editions'].indexOf(e.cat) >= 0 || ['release', 'price', 'platforms', 'preload', 'preorder-cutoff', 'physical'].indexOf(id) >= 0) h += buyHTML();
    if (e.related && e.related.length) h += '<div><div class="kicker" style="margin-bottom:8px">' + esc(t('related')) + '</div><div class="related">' + e.related.map((r) => byId[r]).filter(Boolean).map((r) => { const im = img(r); return '<a class="rel" href="#e/' + r.id + '"><div class="ph">' + (im ? '<img src="' + im.src + '" alt="" loading="lazy">' : '<div style="height:100%;display:grid;place-items:center"><div class="avatar">' + esc(initials(r)) + '</div></div>') + '</div><span>' + esc(t('catsOne.' + r.cat)) + '</span><b>' + esc(tx(r, 'name')) + '</b></a>'; }).join('') + '</div></div>';
    h += '</div></div>' + footerHTML() + '</div>';
    return h;
  }
  function txN(n, f) { // news text with fallbacks (current language -> English -> French)
    const l = S.lang; let v;
    if (n.i18n[l]) v = n.i18n[l][f]; else if (LANGPACK[l] && LANGPACK[l].news && LANGPACK[l].news[n.id]) v = LANGPACK[l].news[n.id][f];
    if (v == null || v === '' || (Array.isArray(v) && !v.length)) v = n.i18n.en[f];
    if (v == null || v === '' || (Array.isArray(v) && !v.length)) v = n.i18n.fr[f];
    return v;
  }
  function viewNews(id) {
    const n = D.news.find((x) => x.id === id); if (!n) return '<div class="empty"><b>404</b></div>';
    const body = txN(n, 'body'); const off = (n.src || 'official') === 'official';
    let host = ''; try { host = new URL(n.url).hostname.replace(/^www\./, ''); } catch (e) { host = ''; }
    const pic = n.img || D.extra.keyart1;
    let h = '<div class="view detail news-article"><div class="detail-hero"><img src="' + pic + '" alt="" fetchpriority="high" style="width:100%;height:100%;object-fit:cover"><div class="topfade"></div><div class="detail-nav"><button class="icon-btn" data-action="back" aria-label="' + esc(t('back')) + '">' + ICON.back + '</button><div class="right"></div></div></div>';
    h += '<div class="detail-head"><div class="kicker">' + esc(fmtDate(n.date)) + ' · ' + esc(t(off ? 'newsOfficial' : 'newsCommunity')) + '</div><h1>' + esc(txN(n, 'title')) + '</h1>' + (body && body.length ? '' : '<p class="tag">' + esc(txN(n, 'summary')) + '</p>') + '</div>';
    h += '<div class="detail-body"><div class="col-main">';
    if (n.video && byId[n.video] && byId[n.video].video && D.videos[byId[n.video].video]) h += videoCard(byId[n.video].video);
    if (body && body.length) h += '<div class="prose">' + body.map((p) => '<p>' + esc(p) + '</p>').join('') + '</div>';
    h += '</div><div class="col-side">';
    h += '<div class="card source-box">' + ICON.shield + '<div><b>' + esc(t(off ? 'newsOfficial' : 'newsCommunity')) + '</b><div class="tiny">' + esc(t('newsSource')) + ' : ' + esc(host) + '</div><div class="tiny">' + esc(fmtDate(n.date)) + '</div></div></div>';
    const rel = (n.related || []).map((r) => byId[r]).filter(Boolean);
    if (rel.length) h += '<div><div class="kicker" style="margin-bottom:8px">' + esc(t('newsRelated')) + '</div><div class="related">' + rel.map((r) => { const im = img(r); return '<a class="rel" href="#e/' + r.id + '"><div class="ph">' + (im ? '<img src="' + im.src + '" alt="" loading="lazy">' : '') + '</div><b>' + esc(tx(r, 'name')) + '</b></a>'; }).join('') + '</div></div>';
    const more = D.news.filter((x) => x.id !== n.id).slice(0, 3);
    if (more.length) h += '<div><div class="kicker" style="margin-bottom:8px">' + esc(t('newsMore')) + '</div><div class="news-list" style="padding:0">' + more.map((x) => newsCard(x, false)).join('') + '</div></div>';
    h += '</div></div>' + footerHTML() + '</div>';
    return h;
  }
  function bump(id) { const i = S.history.indexOf(id); if (i >= 0) S.history.splice(i, 1); S.history.unshift(id); S.history = S.history.slice(0, 40); save(); }

  /* ---------- search ---------- */
  function openSearch() { const d = $('#search-dlg'); $('#search-input').placeholder = t('searchPlaceholder'); if (!d.open) d.showModal(); $('#search-input').value = ''; renderSearch(''); setTimeout(() => $('#search-input').focus(), 50); }
  function renderSearch(q) {
    const box = $('#search-results'); const nq = norm(q.trim());
    if (!nq) { box.innerHTML = '<p class="hint">' + esc(t('searchHint', { n: D.entries.length, p: D.media.length, v: Object.keys(D.videos).length })) + '</p><div class="chips" style="padding:0">' + CATS.slice(0, 7).map((c) => '<a class="chip small" href="#guide/' + c + '" data-action="close-search">' + esc(catName(c)) + '</a>').join('') + '</div>'; return; }
    const score = (e) => { let s = 0; const name = norm(tx(e, 'name')), en = norm(e.i18n.en.name); if (name.indexOf(nq) === 0 || en.indexOf(nq) === 0) s += 10; else if (name.indexOf(nq) >= 0 || en.indexOf(nq) >= 0) s += 6; const hay = norm([tx(e, 'tagline'), tx(e, 'summary'), (tx(e, 'body') || []).join(' '), (tx(e, 'facts') || []).map((f) => f.join(' ')).join(' '), e.i18n.en.summary].join(' ')); if (hay.indexOf(nq) >= 0) s += 2; return s; };
    const hits = D.entries.map((e) => [score(e), e]).filter((x) => x[0] > 0).sort((a, b) => b[0] - a[0]).slice(0, 30).map((x) => x[1]);
    const photos = D.media.filter((m) => norm(m.title).indexOf(nq) >= 0).slice(0, 12);
    let h = '';
    if (hits.length) h += '<div class="sr-group">' + esc(t('results', { n: hits.length })) + '</div>' + hits.map((e) => listRow(e).replace('class="card list-row"', 'class="card list-row" data-action="close-search"')).join('');
    if (photos.length) h += '<div class="sr-group">' + esc(t('photos')) + '</div><div class="photo-grid" style="padding:0;grid-template-columns:repeat(4,1fr)">' + photos.map((m) => '<button data-action="lb" data-idx="' + (m.id - 1) + '"><img src="' + m.src + '" alt="' + esc(m.title) + '" loading="lazy"></button>').join('') + '</div>';
    if (!hits.length && !photos.length) h = '<p class="hint">' + esc(t('noResults', { q })) + '</p>';
    box.innerHTML = h;
  }

  /* ---------- lightbox ---------- */
  let lb = { list: [], i: 0 };
  function openLightbox(list, i) { lb = { list, i }; const d = $('#lightbox'); if (!d.open) d.showModal(); drawLb(); }
  function drawLb() { const m = lb.list[lb.i]; if (!m) return; $('#lb-stage').innerHTML = '<img src="' + (m.hi || m.src) + '" alt="' + esc(m.alt || m.title || '') + '" onerror="this.onerror=null;this.src=\'' + m.src + '\'">'; $('#lb-caption').innerHTML = '<span>' + esc(m.alt || m.title || '') + ' <span class="dim">· ' + esc(t('lightbox.of', { i: lb.i + 1, n: lb.list.length })) + '</span><br><span class="tiny dim">' + esc(t('officialPhoto')) + '</span></span>' + (m.hi ? '<a class="link" target="_blank" rel="noopener" href="' + esc(m.hi.replace(/imwidth=\d+/, 'imwidth=3840')) + '">' + esc(t('lightbox.openOriginal')) + ' ›</a>' : ''); }
  function lbNav(d) { if (!lb.list.length) return; lb.i = (lb.i + d + lb.list.length) % lb.list.length; drawLb(); }

  /* ---------- language sheet ---------- */
  function openLang() { const d = $('#lang-dlg'); $('#lang-body').innerHTML = '<h2>' + esc(t('langPicker')) + '</h2><div class="lang-grid">' + LANGS.map((l) => '<button class="lang-opt' + (l.code === S.lang ? ' active' : '') + '" data-action="set-lang" data-code="' + l.code + '"><span class="fl">' + l.flag + '</span><span>' + esc(l.label) + '</span></button>').join('') + '</div><p class="tiny dim" style="margin-top:12px">' + esc(t('translationNote')) + '</p>'; if (!d.open) d.showModal(); }

  /* ---------- export / import ---------- */
  function exportData() { const blob = new Blob([JSON.stringify({ app: 'leonida', version: VERSION, exportedAt: new Date().toISOString(), state: S }, null, 1)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'leonida-backup.json'; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500); toast(t('me.exported')); }
  function importData(file) { const r = new FileReader(); r.onload = () => { try { const j = JSON.parse(r.result); const st = j.state || j; if (!Array.isArray(st.favs || st.favorites)) throw 0; S.favs = (st.favs || st.favorites).filter((id) => byId[id]); if (Array.isArray(st.history || st.read)) S.history = (st.history || st.read).filter((id) => byId[id]); if (Array.isArray(st.checks)) S.checks = st.checks; if (typeof st.spoilers === 'boolean') S.spoilers = st.spoilers; save(); render(); toast(t('me.imported')); } catch (e) { toast(t('me.importError')); } }; r.readAsText(file); }

  /* ---------- nav & router ---------- */
  const TABS = [['home', 'home'], ['leonida', 'map'], ['guide', 'guide'], ['media', 'news'], ['me', 'me']];
  function renderNav() {
    const route = currentRoute();
    const tabs = TABS.map((x) => '<a class="tab' + (route === x[0] ? ' active' : '') + '" href="#' + x[0] + '">' + ICON[x[1]] + '<span>' + esc(t('nav.' + x[0])) + '</span></a>').join('');
    $('#tabbar').innerHTML = tabs;
    $('#sidenav').innerHTML = '<a class="brand" href="#home"><span class="wordmark">LEONIDA</span><svg class="palm" viewBox="0 0 30 34" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M10 32c4-10 6-17 6-24M16 8C12 2 5 3 2 8c6-2 10-1 14 0M16 8c2-7 7-7 11-4-5 0-8 2-11 4M16 8C9 8 6 14 7 18c2-5 5-8 9-10M16 8c8 0 12 5 12 10-4-5-7-8-12-10M16 8c-2-5-1-7 1-7"/></svg></a><div class="caption">' + esc(t('tagline')) + '</div>' + tabs + '<div class="foot"><b>GTA VI · ' + esc(t('releaseDate')) + '</b>' + esc(t('unofficial')) + '</div>';
    $('#btn-lang').textContent = S.lang.toUpperCase();
    $('#btn-search').setAttribute('aria-label', t('search'));
  }
  function currentRoute() { const h = location.hash.replace(/^#\/?/, ''); const seg = h.split('/'); if (seg[0] === 'e') { const e = byId[seg[1]]; if (!e) return 'home'; if (e.cat === 'places') return 'leonida'; if (e.cat === 'videos' || e.cat === 'music') return 'media'; return 'guide'; } if (seg[0] === 'n') return 'media'; return seg[0] || 'home'; }
  let lastHash = '';
  function render() {
    const h = location.hash.replace(/^#\/?/, ''); const seg = h.split('/');
    const main = $('#content'); let html = '';
    stopAllMedia(); ['#search-dlg', '#lang-dlg', '#lightbox'].forEach((d) => { const el = $(d); if (el.open) el.close(); });
    switch (seg[0]) {
      case 'leonida': html = viewLeonida(); break;
      case 'guide': html = viewGuide(seg[1] && (CATS.indexOf(seg[1]) >= 0 ? seg[1] : seg[1] === 'all' ? 'all' : null)); break;
      case 'media': html = viewMedia(seg[1] && ['news', 'videos', 'photos', 'music'].indexOf(seg[1]) >= 0 ? seg[1] : null); break;
      case 'me': html = viewMe(); break;
      case 'e': html = viewDetail(seg[1]); break;
      case 'n': html = viewNews(seg[1]); break;
      case 'musique': case 'music': location.replace('#media/music'); return;
      case 'carte': location.replace('#leonida'); return;
      case 'encyclopedie': case 'contenu': location.replace('#guide'); return;
      case 'actualites': case 'actus': location.replace('#media'); return;
      case 'progression': case 'espace': location.replace('#me'); return;
      default: html = viewHome();
    }
    main.innerHTML = html;
    main.classList.toggle('detail-page', seg[0] === 'e'); document.body.classList.toggle('is-detail', seg[0] === 'e');
    document.title = (seg[0] === 'e' && byId[seg[1]] ? tx(byId[seg[1]], 'name') + ' — ' : '') + 'Leonida · GTA VI';
    renderNav(); tickCountdown();
    if (seg[0] !== 'e' || !lastHash.startsWith('e/')) window.scrollTo(0, 0); else window.scrollTo(0, 0);
    lastHash = h;
    if (navigator.onLine && window.innerWidth > 480) $$('img[data-hi]').slice(0, 3).forEach((im) => { const hi = new Image(); hi.onload = () => { im.src = hi.src; }; hi.src = im.dataset.hi; });
    const sl = $('#slides'); if (sl) sl.addEventListener('scroll', () => { const i = Math.round(sl.scrollLeft / sl.clientWidth); $$('#dots i').forEach((d, k) => d.classList.toggle('on', k === i)); }, { passive: true });
    if (deferredInstall && $('#install-btn')) $('#install-btn').hidden = false;
    syncRadioUI();
  }

  /* ---------- events ---------- */
  document.addEventListener('click', (ev) => {
    const a = ev.target.closest('[data-action]'); if (!a) return;
    const act = a.dataset.action;
    if (act === 'fav') { ev.preventDefault(); ev.stopPropagation(); toggleFav(a.dataset.fav); return; }
    if (act === 'search') { openSearch(); return; }
    if (act === 'close-search') { $('#search-dlg').close(); return; }
    if (act === 'lang') { openLang(); return; }
    if (act === 'set-lang') { $('#lang-dlg').close(); setLang(a.dataset.code); return; }
    if (act === 'back') { if (history.length > 1) history.back(); else go('home'); return; }
    if (act === 'share') { const e = byId[a.dataset.id]; const url = location.href; const data = { title: tx(e, 'name') + ' — Leonida', text: tx(e, 'tagline') || tx(e, 'summary'), url }; if (navigator.share) navigator.share(data).catch(() => { }); else if (navigator.clipboard) navigator.clipboard.writeText(url).then(() => toast(t('copied'))); return; }
    if (act === 'play-video') { playVideo(a.dataset.id, a.closest('.video-card')); return; }
    if (act === 'play-video-route') { go('e/' + a.dataset.id); setTimeout(() => { const c = $('.video-card[data-video="' + a.dataset.id + '"]'); if (c) playVideo(a.dataset.id, c); }, 80); return; }
    if (act === 'radio') { toggleRadio(a.dataset.id); return; }
    if (act === 'seek') { if (audioId === a.dataset.id && audio && audio.duration) { const r = a.getBoundingClientRect(); audio.currentTime = (ev.clientX - r.left) / r.width * audio.duration; syncRadioUI(); } else toggleRadio(a.dataset.id); return; }
    if (act === 'chapter') { const tt = +a.dataset.t; if (audioId !== a.dataset.id) { toggleRadio(a.dataset.id); audio.addEventListener('loadedmetadata', () => { audio.currentTime = tt; }, { once: true }); } else { audio.currentTime = tt; if (audio.paused) audio.play(); } setTimeout(syncRadioUI, 100); return; }
    if (act === 'single') { const box = $('[data-embed="' + a.dataset.id + '"]'); if (!box) return; if (box.hidden) { stopAllMedia(); $$('.single-embed').forEach((b) => { b.hidden = true; b.innerHTML = ''; }); box.innerHTML = spotifyEmbed(a.dataset.id); box.hidden = false; bump(a.dataset.id); } else { box.hidden = true; box.innerHTML = ''; } return; }
    if (act === 'reveal') { const w = a.closest('.spoiler'); w.outerHTML = $('.blur', w).innerHTML; return; }
    if (act === 'lb') { openLightbox(D.media.map((m) => ({ src: m.src, hi: m.hi, alt: m.title })), +a.dataset.idx); return; }
    if (act === 'lb-entry') { openLightbox(images(byId[a.dataset.entry]), +a.dataset.i); return; }
    if (act === 'lb-close') { $('#lightbox').close(); return; }
    if (act === 'lb-prev') { lbNav(-1); return; }
    if (act === 'lb-next') { lbNav(1); return; }
    if (act === 'cat') { guideFavs = false; guideCat = a.dataset.cat; location.hash = '#guide/' + guideCat; return; }
    if (act === 'cat-favs') { guideFavs = !guideFavs; render(); return; }
    if (act === 'view') { S.view = a.dataset.v; save(); render(); return; }
    if (act === 'pf') { photoFilter = a.dataset.f; render(); return; }
    if (act === 'check') { const id = a.dataset.id, i = S.checks.indexOf(id); if (i >= 0) S.checks.splice(i, 1); else S.checks.push(id); save(); render(); return; }
    if (act === 'spoilers') { S.spoilers = !S.spoilers; save(); render(); return; }
    if (act === 'clear-history') { S.history = []; save(); render(); return; }
    if (act === 'export') { exportData(); return; }
    if (act === 'import') { $('#import-file').click(); return; }
    if (act === 'install') { if (deferredInstall) { deferredInstall.prompt(); deferredInstall = null; a.hidden = true; } return; }
  });
  $('#import-file').addEventListener('change', (e) => { if (e.target.files[0]) importData(e.target.files[0]); e.target.value = ''; });
  $('#search-input').addEventListener('input', (e) => renderSearch(e.target.value));
  $('#search-dlg').addEventListener('click', (e) => { if (e.target === e.currentTarget) e.currentTarget.close(); });
  $('#lang-dlg').addEventListener('click', (e) => { if (e.target === e.currentTarget) e.currentTarget.close(); });
  document.addEventListener('keydown', (e) => { if (e.key === '/' && !$('#search-dlg').open && !/input|textarea/i.test(document.activeElement.tagName)) { e.preventDefault(); openSearch(); } if ($('#lightbox').open) { if (e.key === 'ArrowLeft') lbNav(-1); if (e.key === 'ArrowRight') lbNav(1); } });
  // lightbox swipe
  (function () { let x0 = null; const st = $('#lb-stage'); st.addEventListener('touchstart', (e) => { x0 = e.touches[0].clientX; }, { passive: true }); st.addEventListener('touchend', (e) => { if (x0 == null) return; const dx = e.changedTouches[0].clientX - x0; if (Math.abs(dx) > 50) lbNav(dx < 0 ? 1 : -1); x0 = null; }, { passive: true }); })();
  window.addEventListener('hashchange', render);
  // offline / install
  function netState() { const n = $('#net'); n.hidden = navigator.onLine; n.textContent = t('offline'); }
  window.addEventListener('online', netState); window.addEventListener('offline', netState);
  let deferredInstall = null; window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); deferredInstall = e; const b = $('#install-btn'); if (b) b.hidden = false; });
  window.addEventListener('appinstalled', () => toast(t('installed')));
  if ('serviceWorker' in navigator && location.protocol.indexOf('http') === 0) { window.addEventListener('load', () => { navigator.serviceWorker.register('sw.js').catch(() => { }); }); }

  /* ---------- boot ---------- */
  load(); save();
  document.documentElement.lang = S.lang;
  if (UI[S.lang]) { render(); netState(); } else { const code = S.lang; S.lang = 'en'; render(); netState(); setLang(code); }
})();
