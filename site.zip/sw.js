/* Leonida service worker — app shell + stale-while-revalidate for local assets. External media is never cached. */
const V = 'leonida-v2.1.0';
const SHELL = ['./', './index.html', './css/fonts.css', './css/app.css', './js/content.js', './js/i18n.js', './js/app.js', './js/config.js', './manifest.webmanifest', './icon.svg', './fonts/leonida-0.ttf', './fonts/leonida-1.ttf', './fonts/leonida-2.ttf', './fonts/leonida-3.ttf', './fonts/leonida-4.ttf', './fonts/leonida-5.ttf', './fonts/leonida-6.ttf', './fonts/leonida-7.ttf', './media/news-trailer.jpg'];
self.addEventListener('install', (e) => { e.waitUntil(caches.open(V).then((c) => c.addAll(SHELL.map((u) => new Request(u, { cache: 'reload' })))).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => { e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== V).map((k) => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', (e) => {
  const req = e.request; if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return; // never intercept Rockstar/Spotify streams
  if (req.mode === 'navigate') { e.respondWith(fetch(req).catch(() => caches.match('./index.html'))); return; }
  e.respondWith(caches.match(req, { ignoreSearch: true }).then((hit) => {
    const net = fetch(req).then((res) => { if (res && res.ok && (url.pathname.match(/\.(js|css|ttf|json|webmanifest|svg|png|jpg|webp)$/))) { const copy = res.clone(); caches.open(V).then((c) => c.put(req, copy)); } return res; }).catch(() => hit);
    return hit || net;
  }));
});
